
/**
 * Write a description of class Frog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Trex extends Animal
    implements Walking
{
    public Trex()
    {
     this("Tammy", "I cant reach my head");   
    }
    
    public Trex(String name, String description)
    {
     super(name, description);   
    }
    
    @Override
    
    public String eat()
    {
        return "I chew on cows";
    }
    
    @Override
    
    public String makeNoise()
    {
      return "RAWRWRRRRRR";
    }
    
    
    @Override
    
    public String walk()
    {
        return "THUD THUD";
    }
}
