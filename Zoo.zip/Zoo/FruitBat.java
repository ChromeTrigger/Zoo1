
/**
 * Write a description of class FruitBat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FruitBat extends Animal
    implements Flying, Walking
{
    public FruitBat()
    {
        this("Berry", "It's small and very fast, sucking the blood out of delicious produce.");
    }

    public FruitBat(String name, String description) {
        super(name, description);
        //super calls the parent
    }

    @Override

    public String eat() {
        return "Eats fruit and bugs.";
    }

    @Override
    public String makeNoise() {
        return "Squeak squeak!";
    }
    
    @Override
    
    public String fly() {
        return "flutter..flutter";
    }
    
    @Override
    
    public String walk() {
        return "tip tap.. tip tap...";
    }
}
