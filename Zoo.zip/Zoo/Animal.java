
/**
 * Write a description of class Animal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Animal
{
    /*Instance variables or fields
     * These are equivalent names or for the same thing
     * protected means that these variables are accessible
     */
    protected String name;
    protected String description;
    public static int numAnimals = 0;
    
    public Animal() {
        //Call the other constructor that takes one string parameter,
        //passing in none for the name
        //This is called constructor chaining when one constructor calls another.
        this("none");
    }
    
    public Animal(String name) {
        // Set the name 
        this(name, "none");
    }
    
    public Animal(String name, String description) {
        //Set the name and description for the animal.
        this.name = name;
        this.description = description;
        //increment the numanimals indicating that another animal has been created.
        numAnimals++;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    @Override /* This annotation (basically Java metadata or data about data)
               * means that we are telling the compiler to check and make sure
               * a parent (super class) contains a toString() method
               */
    public String toString() {
        return this.name + ": " + this.description;
    }
    
    public abstract String eat();
    
    public abstract String makeNoise();
    
    
    
    
}
