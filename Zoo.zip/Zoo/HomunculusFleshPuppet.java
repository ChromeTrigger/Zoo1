
/**
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public class HomunculusFleshPuppet extends Animal implements Walking
{
    /**
     * Construction for objects of class lizalfo
     */
    public HomunculusFleshPuppet()
    {
        this("Homunculus Flesh Puppet" , "It has escaped...");
    }
    public HomunculusFleshPuppet(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "your cat";
    }
    @Override
    public String makeNoise()
    {
        return "slurp";
    }
    @Override
    public String walk()
    {
        return "*crawls on all five hands on the ceiling*";
    }
    
    
}
