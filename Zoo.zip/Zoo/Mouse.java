
/**
 * Write a description of class Mouse here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Mouse extends Animal
{
    public Mouse()
    {
        this("Mickey Mouse", "I can find cheese in a maze.");
    }
    
    public Mouse(String name, String description) {
        super(name, description);
    }
    
    @Override
    
    
    public String eat() {
        return "Eats cheese";
    }
    
    @Override 
    
    
    public String makeNoise() {
        return "Squeek *sniffle*";
    }
}
