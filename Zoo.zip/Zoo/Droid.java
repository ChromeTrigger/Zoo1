
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Droid extends Animal implements Spinning
{
    /**
     * Constructor for objects of class phish
     */
    public Droid()
    {
        this("IG Model Droid", " He has a PhD in spin.");
    }
    
    public Droid(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "biokerosene jet fuel";
    }
    @Override
    public String makeNoise()
    {
        return "manufacturers' protocol dictates I cannot be captured. I must self-destruct.";
    }
    @Override
    public String spin()
    {
       return "";
    }
}
