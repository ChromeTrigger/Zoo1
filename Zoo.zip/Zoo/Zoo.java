import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Zoo
{
    public static int slot1;
    public static int slot2;
    public static int slot3;
    public static void main(String[] args) throws InterruptedException {
        List<Animal> animals = new ArrayList<Animal>();
        int max = 100;
        int min = 0;
        int range2 = 10 - 1;
        int range3 = 10 - 1;
        int range4 = 10 - 1;
        double cash = 0.0;
        System.out.println("Welcome to the Communist manifesto Zoo! Where the foods not apparent, and the water is full of lead.");
        System.out.println("We hope that 'we' can get along just fine. :\n");
        //delayDots(3);
        System.out.print("Building the cages \n");
        //delayDots(3);
        System.out.println("Populating the animals \n");
        populateAnimals(animals);
        //delayDots(3);
        System.out.println("Hiring zookeepers.\n");
        //delayDots(3);
        
        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do.\n");
        String text = in.nextLine();
        String msg = "";
        
        
        for(Animal a :animals)
        {
            if (a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n" + w.walk() + "\n"; 
        }
        
        while(!text.equals("leave"))
        {
            switch(text)
            {
                case "Help" :
                msg = "You can visit cages to see the different animals. \n You can Look up,Down, around, or you can Turn around to see specific animals. \n You can also head to the Concessions stand to get items, or, you can Add funds to get money for it. \n You can always check your wallet by typing My wallet. \n You can also gamble by typing Gamble.";
                break;
                
                case "Visit cages" :
                msg = visitCages(animals);
                break;
                
                case "Look up" :
                msg = lookUp(animals);
                break;
                
                case "Look around" :
                msg = lookAround(animals);
                break;
                
                case "Turn around" :
                msg = turnAround(animals);
                break;
                
                case "Look down" :
                msg = lookDown(animals);
                break;
                
                case "Add funds" :
                msg = "How much? $5.00, $10.00, $20.00?";
                break;
                
                case "Gamble" :
                if(cash < 5.00){
                    msg = "You do not have the money to gamble here. Get out!";
                }
                System.out.println("Spin the slots, take the risk!!!");
                //delayDots(3);
                if(cash >= 5.00){
                    cash = cash - 5.00;
                    slot1 = (int)(Math.random() * range2) + 1;
                    slot2 = (int)(Math.random() * range3) + 1;
                    slot3 = (int)(Math.random() * range4) + 1;
                    System.out.print(slot1);
                    System.out.print(slot2);
                    System.out.print(slot3);
                    System.out.print("\n");
                    //delayDots(3);
                    msg = "Try again, you might get the jackpot ;)";
                
                    if(slot1 == slot2){
                        System.out.println("You won the small jackpot!");
                        cash = cash + 100.00;
                    }
                    if(slot2 == slot3){
                        System.out.println("You won the small jackpot!");
                        cash = cash + 100.00;
                    }
                    if(slot1 == slot3){
                        System.out.println("You won the small jackpot!");
                        cash = cash + 100.00;
                    }
                    if(slot1 == slot2 && slot1 == slot3){
                        System.out.println("You won the jackpot!");
                        cash = cash + 1000.00;
                    }
                }
                break;
                
                case "Concessions stand" :
                msg = "What do you want? Food, drink, or change?";
                break;
                
                case "Food" :
                if(msg == "What do you want? Food, drink, or change?")
                {
                    msg = "We have Nachos, Chicken, Steak, and Fries. Which would you like?";
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "Steak" :
                if(msg == "We have Nachos, Chicken, Steak, and Fries. Which would you like?")
                {
                    System.out.println("That will be $12.00.");
                    if(cash <= 12.00)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 12.00)
                    {
                        cash = cash - 12.00;
                        msg = "You have " + cash + " left in your wallet.";
                       
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
               
                break;
                
                case "Fries" :
                if(msg == "We have Nachos, Chicken, Steak, and Fries. Which would you like?")
                {
                    System.out.println("That will be $5.00.");
                    if(cash <= 5.00)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 5.00)
                    {
                        cash = cash - 5.00;
                        msg = "You have " + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "Chicken" :
                if(msg == "We have Nachos, Chicken, Steak, and Fries. Which would you like?")
                {
                    System.out.println("That will be $8.00.");
                    if(cash <= 8.00)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 8.00)
                    {
                        cash = cash - 8.00;
                        msg = "You have " + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "Nachos" :
                if(msg == "We have Nachos, Chicken, Steak, and Fries. Which would you like?")
                {
                    System.out.println("That will be $12.00.");
                    if(cash <= 6.00)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 6.00)
                    {
                        cash = cash - 6.00;
                        msg = "You have " + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                
                case "$10.00" : 
                if(msg.equals("How much? $5.00, $10.00, $20.00?"))
                {
                cash = cash + 10.00;
                System.out.println("You added $10.00 to your account.");
                msg = "";
            }
            else{
                msg = "You stand in awe with everything you could do.";
            }
                break;
                
                case "$20.00" : 
                if(msg.equals("How much? $5.00, $10.00, $20.00?"))
                {
                cash = cash + 20.00;
                System.out.println("You added $20.00 to your account.");
                msg = "";
            }
            else{
                msg = "You stand in awe with everything you could do.";
            }
                break;
                
     
                case "$5.00" : 
                if(msg.equals("How much? $5.00, $10.00, $20.00?"))
                {
                    cash = cash + 5.00;
                    System.out.println("You added $5.00 to your account.");
                    msg = "";
            }
            else{
                msg = "You stand in awe with everything you could do.";
            }
                break;
                
                case "SOMEONE FELL IN THE LEGO CITY RIVER! PREPARE THE HELICOPTER!" :
                msg = "HEY!!!!!";
                break;
                
                case "Drink" :
                msg = "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?";
                break;
                
                case "Monster" :
                System.out.println("That will be $3.50.");
                if(msg == "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?")
                {
                    System.out.println("That will be $3.50.");
                    if(cash <= 3.50)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 3.50)
                    {
                        cash = cash - 3.50;
                        msg = "You have " + "$" + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "Rootbeer" :
                if(msg == "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?")
                {
                    System.out.println("That will be $1.50.");
                    if(cash <= 1.50)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 1.50)
                    {
                        cash = cash - 1.50;
                        msg = "You have " + "$" + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "Coke" :
                if(msg == "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?")
                {
                    System.out.println("That will be $2.10.");
                    if(cash <= 2.10)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 2.10)
                    {
                        cash = cash - 2.10;
                        msg = "You have " + "$" + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                //This code below I thought would do what i want,but is completely useless.
                //if(msg != "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?" || msg != "You have " + cash + " left in your wallet.")
                    //{
                        //msg = "You stand in awe with with everything you could do.";
                    //}
                break;
                
                case "Sprite" :
                if(msg == "We have Monster, Sprite, Rootbeer, Coke, and Dr. Pepper. Which would you prefer?")
                {
                    System.out.println("That will be $1.50.");
                    if(cash <= 1.50)
                    {
                        msg = "You do not have the funds to pay for this.";
                    }
                    if(cash >= 1.50)
                    {
                        cash = cash - 1.50;
                        msg = "You have " + "$" + cash + " left in your wallet.";
                    }
                    
                }
                else
                {
                    msg = "You stand in awe with everything you could do.";
                }
                break;
                
                case "My wallet" :
                
                int stolen = randomWithRange(0,100);
                System.out.println(stolen);
                if (stolen >= 90)
                {
                    msg = "Your wallet has been stolen, You have to die now.";
                }
                else
                {
                System.out.println("You found your wallet, However, you feel as if something is waiting to snatch it though...");
                msg = "You have " + "$" + cash;
                }
                break;
                
                /** case "Test" :
                 * System.out.println("Okay, first question is: When it comes to the Beholder, what is his name in this zoo?");
                 * if(msg.equals("Brad"))
                 * {
                 *     System.out.println("You won");
                 *  }
                 *  break;
                 */
                
                default : msg = "You stand in awe with everything you could do.";
            }
            System.out.println("\n" + msg);
            //delayDots(3);
            System.out.println("\n" + "What now?");
            if (msg == "Your wallet has been stolen, You have to die now.")
            {
                System.exit(1);
            }
            text = in.nextLine();
            //System.out.println("\f"); This clears the screen of anything that had been typed previously. Will not clear screen of something after this code.
        }
        }
    
    }
    public static int randomWithRange(int min, int max) {
          //defining method for a random number generator
            int range = (max - min) + 1;     
            return (int)(Math.random() * range) + min;
        }    
        
    public static String visitCages(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n     " + a.getDescription() + ": " + "\n" + a.makeNoise();
        }
        return msg;
    }
    
    public static String lookAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n     " + w.walk() + "\n";
            }
        }
        return msg;
    }
    
    
    
    public static String lookUp(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + ": \n     " + f.fly() + "\n";
            }
        }
        return msg;
    }
    
    public static String lookDown(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ": \n     " + s.swim() + "\n";
            }
        }
        return msg;
    }
    
    public static String turnAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            if(a instanceof Spinning)
            {
                Spinning s = (Spinning)a;
                msg += a.getName() + ": \n     " + s.spin() + "\n";
            }
        }
        return msg;
    }
    
    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for (int i=0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }
    
    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }
    
    public static void populateAnimals(List<Animal> animals)
    {
        Mouse a1 = new Mouse();
        animals.add(a1);
        
        BacterialPhage a2 = new BacterialPhage();
        animals.add(a2);
        
        MindFlayer a3 = new MindFlayer();
        animals.add(a3);
        
        Beholder a4 = new Beholder();
        animals.add(a4);
        
        Phish a5 = new Phish();
        animals.add(a5);
        
        Bigfoot a6 = new Bigfoot();
        animals.add(a6);
        
        Lochnessmonster a7 = new Lochnessmonster();
        animals.add(a7);
        
        Platypus a8 = new Platypus();
        animals.add(a8);
        
        JapaneseGiantSalamander a9 = new JapaneseGiantSalamander();
        animals.add(a9);
        
        Bunny a10 = new Bunny();
        animals.add(a10);
        
        Vince a11 = new Vince();
        animals.add(a11);
        
        Megalodon a12 = new Megalodon();
        animals.add(a12);
        
        Lizalfo a13 = new Lizalfo();
        animals.add(a13);
        
        GoldFish a14 = new GoldFish();
        animals.add(a14);
        
        Abominablesnowman a15 = new Abominablesnowman();
        animals.add(a15);
        
        goomba a16 = new goomba();
        animals.add(a16);
        
        Thwomp a17 = new Thwomp();
        animals.add(a17);
        
        HomunculusFleshPuppet a18 = new HomunculusFleshPuppet();
        animals.add(a18);
        
        Duck a19 = new Duck();
        animals.add(a19);
        
        Trex a20 = new Trex();
        animals.add(a20);
        
        LR57CombatDroid a21 = new LR57CombatDroid();
        animals.add(a21);
        
        Bella a22 = new Bella();
        animals.add(a22);
        
        FruitBat a23 = new FruitBat();
        animals.add(a23);
        
        SunBear a24 = new SunBear();
        animals.add(a24);
        
        Llama a25 = new Llama();
        animals.add(a25);
        
        IronTarkus a26 = new IronTarkus();
        animals.add(a26);
        
        RedCrowCrane a27 = new RedCrowCrane();
        animals.add(a27);
        
        
        
        
        
        
        

    }
}
