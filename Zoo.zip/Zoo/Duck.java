
/**
 * Abstract class Duck - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Duck extends Animal
{
    /**
     * Construction for objects of class Llama
     */
    public Duck()
    {
        this("Opie the Dopey Duck" , "Enjoys fishing with his father");
        
    }
    
    /**
     * Duck Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Duck(String name, String description) {
        super(name, description);
    }
    
    @Override 
    public String eat()
    {
        return "MMmmm bReAd";
    }
    
    @Override
    public String makeNoise()
    {
        return "Quackk";
    }
}
