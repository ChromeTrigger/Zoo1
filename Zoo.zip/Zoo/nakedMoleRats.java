
/**
 * Write a description of class nakedMoleRats here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class nakedMoleRats extends Animal 
implements Walking
{
public nakedMoleRats() {
 this("communist naked mole rat community" , "they are all equally naked");
  }  
public nakedMoleRats(String name, String description) {
    super(name, description);
}
@Override

public String eat() {
   return("gnaws blindly");
}
@Override
public String makeNoise() {
    return("lowly infidel grunts");
}
@Override
public String walk() {
    return "Crawl and wriggle";
}
}
