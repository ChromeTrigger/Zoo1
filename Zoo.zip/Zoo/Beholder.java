
/**
 * Write a description of class Beholder here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Beholder extends Animal implements Flying
{
    public Beholder()
    {
        this("Beholder Brad", "I am a apex predator when it comes to hunting anything that lives.");
    }
    
    public Beholder(String name, String description) {
        super(name, description);
    }
    
    @Override
    
    
    public String eat() {
        return "Remains of dumb adventurers";
    }
    
    @Override 
    
    
    public String makeNoise() {
        return "Mind breaking scream.";
    }
    
    @Override
    
    public String fly() {
        return "He hovers still in the air, as if a great prescense is within him.";
    }
}