
/**
 * Write a description of interface Spinning here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Spinning
{
    public String spin();
}
